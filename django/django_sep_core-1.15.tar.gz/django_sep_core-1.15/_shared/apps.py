from django.apps import AppConfig

# Constantes pour les profils utilisateurs
ADMINISTRATEUR = 'Administrateur'
TM_ASSISTANTE = 'TM_Assistante'
INVITE = 'Invité'
TM_PILOTE = 'TM_Pilote'
TM_ADMINISTRATIF = 'TM_Administratif'
TM_CAP = 'TM_CAP'
TM_CONTROLE_COMMANDE = 'TM_Controle_Commande'
TM_DIRECTION = 'TM_Direction'
TM_DSQ = 'TM_DSQ'
TM_FONCTION_SUPPORT = 'TM_Fonction_Support'
TM_INFORMATIQUE = 'TM_Informatique'
TM_INSTALLATIONS_1300 = 'TM_Installations_1300'
TM_INSTALLATIONS_900_N4 = 'TM_Installations_900_N4'
TM_INTERFACE_SITE = 'TM_Interface_Site'
TM_MECANIQUE = 'TM_Mecanique'
TM_METHODES = 'TM_Methodes'
TM_METIERS = 'TM_Metiers'
TM_PROJETS = 'TM_Projets'
TM_PROJETS_1300_N4 = 'TM_Projets_1300_N4'
TM_PROJETS_900 = 'TM_Projets_900'
TM_PROJETS_GÉNÉRALISATION_VD4 = 'TM_Projets_Généralisation_VD4'
TM_QUALIF = 'TM_Qualif'
TM_REFERENT_ENTREPRISE = 'TM_REFERENT_ENTREPRISE'
TM_RELEVES_SITES = 'TM_Releves_Sites'

LDAP_SERVER_HOST = 'srv-dc01.sep.local'
LDAP_USER = 'SEP\\FABAGN'
LDAP_PASSWORD = "J'adoreLesChouchous"


class SharedConfig(AppConfig):
    name = '_shared'
