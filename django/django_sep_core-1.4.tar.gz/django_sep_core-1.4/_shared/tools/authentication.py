from django.contrib.auth.middleware import RemoteUserMiddleware
import django.contrib.auth.backends
from django.contrib.auth import get_user_model

UserModel = get_user_model()

class CustomMiddleware(RemoteUserMiddleware):
    header = 'HTTP_X_REMOTE_USER'


class RemoteUserBackend(django.contrib.auth.backends.RemoteUserBackend):
    def authenticate(self, request, remote_user):
        if remote_user is not None:
            remote_user = remote_user.upper()
        return super().authenticate(request, remote_user)


class ModelBackend(django.contrib.auth.backends.ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwars):
        if username is not None:
            username = username.upper()
        return super().authenticate(request, username, password, **kwars)
