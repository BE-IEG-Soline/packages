from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('_shared', '0005_alter_qualification_table'),
    ]

    operations = [
        migrations.AddField(
            model_name='contrat',
            name='code',
            field=models.CharField(default='CODE_TEMP', max_length=10),
        ),
        migrations.AlterField(
            model_name='contrat',
            name='libelle',
            field=models.CharField(default='CODE_TEMP', max_length=24),
        ),
    ]
