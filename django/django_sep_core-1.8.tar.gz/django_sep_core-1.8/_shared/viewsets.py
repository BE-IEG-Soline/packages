from rest_framework import serializers
from rest_framework import viewsets
from _shared.models import History, Societe, Validite, Palier, Site, Tranche, Contrat, Uce, Service, \
    CahierDesChargesInterne, \
    Qualification, Batiment, Local, Voile
from _shared.serializers import SocieteSerializer, ValiditeSerializer, PalierSerializer, SiteSerializer, \
    TrancheSerializer, ContratSerializer, UceSerializer, ServiceSerializer, CahierDesChargesSerializer, \
    QualificationSerializer, BatimentSerializer, LocalSerializer, VoileSerializer


class MultiSerializerViewSet(viewsets.ModelViewSet):
    serializers = {'default': None,}

    def get_serializer_class(self):
        return self.serializers.get(self.action, self.serializers['default'])


class HistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = History
        fields = '__all__'


class HistoryViewSet(viewsets.ModelViewSet):
    queryset = History.objects.all()
    serializer_class = HistorySerializer


class SocieteViewSet(viewsets.ModelViewSet):
    queryset = Societe.objects.all()
    serializer_class = SocieteSerializer

class ValiditeViewSet(viewsets.ModelViewSet):
    queryset = Validite.objects.all()
    serializer_class = ValiditeSerializer


class PalierViewSet(viewsets.ModelViewSet):
    queryset = Palier.objects.all()
    serializer_class = PalierSerializer


class SiteViewSet(viewsets.ModelViewSet):
    queryset = Site.objects.all()
    serializer_class = SiteSerializer


class TrancheViewSet(viewsets.ModelViewSet):
    queryset = Tranche.objects.all()
    serializer_class = TrancheSerializer


class ContratViewSet(viewsets.ModelViewSet):
    queryset = Contrat.objects.all()
    serializer_class = ContratSerializer


class UceViewSet(viewsets.ModelViewSet):
    queryset = Uce.objects.all()
    serializer_class = UceSerializer


class ServiceViewSet(viewsets.ModelViewSet):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer


class CahierDesChargesViewSet(viewsets.ModelViewSet):
    queryset = CahierDesChargesInterne.objects.all()
    serializer_class = CahierDesChargesSerializer


class QualificationViewSet(viewsets.ModelViewSet):
    queryset = Qualification.objects.all()
    serializer_class = QualificationSerializer


class BatimentViewSet(viewsets.ModelViewSet):
    queryset = Batiment.objects.all()
    serializer_class = BatimentSerializer


class LocalViewSet(viewsets.ModelViewSet):
    queryset = Local.objects.all()
    serializer_class = LocalSerializer


class VoileViewSet(viewsets.ModelViewSet):
    queryset = Voile.objects.all()
    serializer_class = VoileSerializer


