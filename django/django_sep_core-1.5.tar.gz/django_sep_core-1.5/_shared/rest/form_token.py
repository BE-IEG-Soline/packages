from rest_framework.views import APIView
from django.http import JsonResponse
from django.middleware import csrf


class FormToken(APIView):
    queryset = None

    def get(self, request):
        # simply get a new token
        token = csrf.get_token(request)
        return JsonResponse(token, safe=False)
