import json

from django.contrib.auth import get_user_model
from django.http import HttpResponse
