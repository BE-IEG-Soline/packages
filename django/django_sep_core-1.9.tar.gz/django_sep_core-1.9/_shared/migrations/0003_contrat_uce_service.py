from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):

    dependencies = [
        ('_shared', '0002_palier_site_validite_tranche'),
    ]

    operations = [
        migrations.CreateModel(
            name='Contrat',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('user_cr', models.CharField(max_length=32)),
                ('date_cr', models.DateField(auto_now_add=True)),
                ('user_up', models.CharField(max_length=32)),
                ('date_up', models.DateField(auto_now=True)),
                ('libelle', models.CharField(max_length=10)),
            ],
            options={
                'db_table': 'shared_contrat',
                'managed': True,
            },
        ),
        migrations.CreateModel(
            name='Uce',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('user_cr', models.CharField(max_length=32)),
                ('date_cr', models.DateField(auto_now_add=True)),
                ('user_up', models.CharField(max_length=32)),
                ('date_up', models.DateField(auto_now=True)),
                ('code', models.CharField(max_length=32)),
                ('lettre', models.CharField(max_length=2)),
                ('libelle', models.CharField(max_length=32)),
                ('adresse', models.CharField(max_length=200)),
                ('ville', models.CharField(max_length=64)),
                ('tel_accueil', models.CharField(max_length=20)),
            ],
            options={
                'db_table': 'shared_uce',
                'managed': True,
            },
        ),
        migrations.CreateModel(
            name='Service',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('user_cr', models.CharField(max_length=32)),
                ('date_cr', models.DateField(auto_now_add=True)),
                ('user_up', models.CharField(max_length=32)),
                ('date_up', models.DateField(auto_now=True)),
                ('code', models.CharField(max_length=10)),
                ('libelle', models.CharField(max_length=64)),
                ('uce', models.ForeignKey(on_delete=django.db.models.deletion.RESTRICT, related_name='services', to='_shared.uce')),
            ],
            options={
                'db_table': 'shared_service',
                'managed': True,
            },
        ),
        migrations.CreateModel(
            name='Qualification',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('user_cr', models.CharField(max_length=32)),
                ('date_cr', models.DateField(auto_now_add=True)),
                ('user_up', models.CharField(max_length=32)),
                ('date_up', models.DateField(auto_now=True)),
                ('libelle', models.CharField(max_length=64)),
            ],
            options={
                'db_table': 'shared_qualification',
                'managed': True,
            },
        ),
    ]

