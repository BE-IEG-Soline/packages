from itertools import chain

from django.contrib.auth import update_session_auth_hash, get_user_model
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.models import User, Permission, Group
from django.contrib.sessions.models import Session
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q
from django.http import HttpRequest, HttpResponseForbidden, HttpResponseBadRequest, HttpResponse
from django.http.response import JsonResponse
from ldap3 import Server, Connection, ALL, SUBTREE, ALL_ATTRIBUTES
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
import json

from _shared.apps import TM_INFORMATIQUE, TM_METHODES, TM_QUALIF, INVITE, LDAP_SERVER_HOST, LDAP_USER, LDAP_PASSWORD
from _shared.models import Profile
from _shared.serializers import ProfileSerializer, UserSerializer, SocieteSerializer

UserClass = get_user_model()


class Logout(APIView):
    queryset = None

    def get(self, request, format=None):
        # simply delete the token to force a login
        request.user.auth_token.delete()
        return Response(status=status.HTTP_200_OK)


def change_user_password(request: HttpRequest):
    if not request.user.is_authenticated:
        return HttpResponseForbidden("only authenticated user can change his/her password")

    if request.method != 'PATCH':
        return HttpResponseForbidden("only POST Protocol is allowed for save-week")

    body_decode = request.body.decode('utf-8')
    data = json.loads(body_decode)

    if not data['old_password'] or not data['new_password1'] or not data['new_password2']:
        return HttpResponseBadRequest('Password fields must be filled')

    if data['new_password1'] != data['new_password2']:
        return HttpResponseBadRequest('New password and password confirmation fields must be identic')

    if data['new_password1'] == data['old_password']:
        return HttpResponseBadRequest('New password and old password fields must be different')

    if request.user.check_password(data['old_password']):
        # changement du mot de passe
        form = PasswordChangeForm(user=request.user, data=data)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
        else:
            return HttpResponseBadRequest('Erreur lors de la validation du formulaire')
    else:
        return HttpResponseForbidden("Old password wasn't the good one")

    return HttpResponse(status=204)


def get_manager(user: UserClass):
    try:
        data = UserSerializer(user.profile.manager).data
        data['manager'] = get_manager(user.profile.manager)
    except:
        data = None
    return data


def get_upper_user_hierarchy(request: HttpRequest):
    data = get_manager(request.user)
    return HttpResponse(json.dumps(data), content_type='application/json')


def get_subordinates(user: UserClass):
    data = []
    for collab in user.manager_collaborateurs.all().order_by('user__last_name'):
        serialized_collab = UserSerializer(collab.user).data
        serialized_collab['collaborateurs'] = get_subordinates(collab.user)
        data.append(serialized_collab)

    return data


def get_lower_user_hierarchy(request: HttpRequest):
    data = get_subordinates(request.user)
    return HttpResponse(json.dumps(data), content_type='application/json')


def get_perms(request: HttpRequest):
    """
    Get Permissions of user (group and personal perm)
    :param request:
    :return: HttpResponse
    """
    groups_list = []
    permission_list = []

    if request.user.is_superuser:
        for groupe in Group.objects.all():
            groups_list.append(groupe.name)
        for permission in Permission.objects.all():
            if permission.codename not in permission_list:
                permission_list.append(permission.codename)
    else:
        liste_groupes = Group.objects.filter(user=request.user.id)
        for groupe in liste_groupes:
            groups_list.append(groupe.name)

            # permissions des groupes auxquels l'utilisateur appartient
            for permission in groupe.permissions.all():
                if permission.codename not in permission_list:
                    permission_list.append(permission.codename)

        # permissions de l'utilisateur
        permissions = Permission.objects.filter(user=request.user.id)
        for permission in permissions:
            if permission.codename not in permission_list:
                permission_list.append(permission.codename)

    return HttpResponse(json.dumps(
        {'user_permissions': permission_list, 'user_groups': groups_list, 'username': request.user.username}),
        content_type='application/json')


def get_user_informations(request: HttpRequest):
    # get user's information, with groups and permissions enclosed
    groups = []
    for g in request.user.groups.all():
        groups.append(g.name)

    permissions = []
    for p in request.user.get_all_permissions():
        permissions.append(p)

    user_informations = {
        'pk': request.user.pk,
        'username': request.user.username,
        'full_name': f"{request.user.last_name} {request.user.first_name}".strip(),
        'first_name': request.user.first_name,
        'last_name': request.user.last_name,
        'email': request.user.email,
        'is_staff': request.user.is_staff,
        'is_superuser': request.user.is_superuser,
        'last_login': request.user.last_login,
        'groups': groups,
        'permissions': permissions,
    }
    return JsonResponse(user_informations)


def get_simple_user_list(request: HttpRequest) -> JsonResponse:
    users = []
    user_list = User.objects.select_related('profile',
                                            'profile__manager',
                                            'profile__suppleant',
                                            'profile__company').prefetch_related('groups',
                                                                                 'groups__permissions',
                                                                                 'user_permissions')
    if 'actifs_seuls' in request.GET:
        user_list = user_list.filter(is_active=True)

    for user in user_list.all():
        company = user.profile.company if hasattr(user, 'profile') and hasattr(user.profile, 'company') else None
        groups = []
        for g in user.groups.all():
            groups.append(g.name)

        users.append({
            'pk': user.pk,
            'id': user.id,
            'username': user.username,
            'full_name': f"{user.last_name} {user.first_name}".strip(),
            'first_name': user.first_name,
            'last_name': user.last_name,
            'email': user.email,
            'is_staff': user.is_staff,
            'is_superuser': user.is_superuser,
            'last_login': user.last_login,
            'groupes': groups,
            'company': {'id': company.id, 'raison_sociale': company.raison_sociale} if company else {'id': None, 'raison_sociale': None},
        })

    return JsonResponse(users, safe=False)

class UserList(APIView):
    queryset = None

    def get(self, request: HttpRequest):
        user_informations = []

        # on va voir si la requete a une restriction sur le groupe auquel devraient appartenir les utilisateurs
        if 'group' in request.GET:
            user_list = User.objects.select_related('profile', 'profile__manager', 'profile__suppleant', 'profile__company').prefetch_related('groups', 'groups__permissions', 'user_permissions').filter(groups__name=request.GET['group'], is_active=True)
        else:
            user_list = User.objects.select_related('profile', 'profile__manager', 'profile__suppleant', 'profile__company').prefetch_related('groups', 'groups__permissions', 'user_permissions').filter(is_active=True).all()

        for user in user_list:
            # get user's information, with groups and permissions enclosed
            groups = []
            for g in user.groups.all():
                groups.append(g.name)

            permissions = []
            if 'permissions' in request.GET and request.GET['permissions'] == 'no':
                pass
            else:
                for p in user.get_all_permissions():
                    permissions.append(p)

            manager = user.profile.manager if hasattr(user, 'profile') and hasattr(user.profile, 'manager') else None
            suppleant = user.profile.suppleant if hasattr(user, 'profile') and hasattr(user.profile, 'suppleant') else None
            company = user.profile.company if hasattr(user, 'profile') and hasattr(user.profile, 'company') else None


            user_informations.append({
                'pk': user.pk,
                'id': user.id,
                'username': user.username,
                'full_name': f"{user.last_name} {user.first_name}".strip(),
                'first_name': user.first_name,
                'last_name': user.last_name,
                'email': user.email,
                'is_staff': user.is_staff,
                'is_superuser': user.is_superuser,
                'last_login': user.last_login,
                'groups': groups,
                'permissions': permissions,
                'manager': UserSerializer(manager).data,
                'suppleant': UserSerializer(suppleant).data,
                'company': SocieteSerializer(company).data
            })
        return JsonResponse(user_informations, safe=False)


def get_user_profile(request: HttpRequest):
    # récupération du profil utilisateur
    if hasattr(request.user, 'profile') and request.user.profile is not None:
        data = ProfileSerializer(request.user.profile).data
        data['manager'] = UserSerializer(request.user.profile.manager).data
        data['suppleant'] = UserSerializer(request.user.profile.suppleant).data
        data['company'] = SocieteSerializer(request.user.profile.company).data
        data['hexagramme'] = request.user.profile.hexagramme
        data['trigramme'] = request.user.profile.trigramme
    else:
        profile = Profile()
        profile.user = request.user
        data = ProfileSerializer(profile).data
        data['manager'] = None
        data['suppleant'] = None
        data['company'] = None
        data['hexagramme'] = None
        data['trigramme'] = None

    return HttpResponse(json.dumps(data), content_type='application/json')


def get_ldap_informations(user: User):
    ldap_server_host = LDAP_SERVER_HOST
    ldap_user = LDAP_USER
    ldap_password = LDAP_PASSWORD

    ldap_server = Server(ldap_server_host, get_info=ALL)
    ldap_connection = Connection(ldap_server, user=ldap_user, password=ldap_password, auto_bind=True)
    search_result = ldap_connection.search(search_base='OU=Utilisateurs,OU=SEP,DC=sep,DC=local',
                                           search_filter=f'(sAMAccountName={user.username}*)',
                                           search_scope=SUBTREE,
                                           attributes=ALL_ATTRIBUTES,
                                           get_operational_attributes=True)
    if search_result:
        user.first_name = ldap_connection.entries[0]['givenName']
        user.last_name = ldap_connection.entries[0]['sn']
        user.email = ldap_connection.entries[0]['mail']

        user.save()
        for group in ldap_connection.entries[0]['memberOf']:
            if 'G-Pole-Informatique' in group.decode("utf-8"):
                new_group = Group.objects.get(name=TM_INFORMATIQUE)
            elif 'G-Pole-Methodes' in group.decode("utf-8"):
                new_group = Group.objects.get(name=TM_METHODES)
            elif 'G-Cellule-Qualif' in group.decode("utf-8"):
                new_group = Group.objects.get(name=TM_QUALIF)
            else:
                new_group = Group.objects.get(name=INVITE)
            user.groups.add(new_group)


def get_groups(user: User):
    groups_list = []
    for groupe in Group.objects.filter(user=user.id):
        groups_list.append(groupe.name)

    return groups_list


def get_permissions(user: User):
    permission_list = []

    if user.is_superuser:
        for permission in Permission.objects.all():
            if permission.codename not in permission_list:
                permission_list.append(permission.codename)
    else:
        for groupe in Group.objects.filter(user=user.id):
            for permission in groupe.permissions.all():
                if permission.codename not in permission_list:
                    permission_list.append(permission.codename)

        for permission in Permission.objects.filter(user=user.id):
            if permission.codename not in permission_list:
                permission_list.append(permission.codename)

    return permission_list


def is_kerberos_authenticated(request: HttpRequest):
    if request.user.is_authenticated:
        return {'permissions': get_permissions(request.user),
                'groupes': get_groups(request.user),
                'user': {'username': request.user.username,
                         'pk': request.user.id,
                         'email': request.user.email,
                         'first_name': request.user.first_name,
                         'last_name': request.user.last_name
                         }
                }
    else:
        return None


def is_already_logged_in(request: HttpRequest):
    try:
        Session.objects.get(session_key=request.session.session_key)
        user_data = is_kerberos_authenticated(request)
        if user_data:
            return HttpResponse(json.dumps(user_data), content_type='application/json')
        else:
            return HttpResponse(status=204)
    except ObjectDoesNotExist:
        return HttpResponse(status=204)


def refresh_connected_user_data(request: HttpRequest) -> JsonResponse:
    # en premier, vérification si l'utilisateur est bien connecté
    user = None
    if request.user.is_authenticated:
        user = {
            'id': request.user.id,
            'pk': request.user.id,
            'username': request.user.username,
            'email': request.user.email,
            'first_name': request.user.first_name,
            'last_name': request.user.last_name,
            'manager': {
                'id': request.user.profile.manager.id,
                'pk': request.user.profile.manager.id,
                'username': request.user.profile.manager.username,
                'email': request.user.profile.manager.email,
                'first_name': request.user.profile.manager.first_name,
                'last_name': request.user.profile.manager.last_name,
                'company': {
                    'raison_sociale': request.user.profile.manager.profile.company.raison_sociale,
                    'adresse': request.user.profile.manager.profile.company.adresse,
                    'code_postal': request.user.profile.manager.profile.company.code_postal,
                    'ville': request.user.profile.manager.profile.company.ville,
                    'site_web': request.user.profile.manager.profile.company.site_web,
                    'tel_accueil': request.user.profile.manager.profile.company.tel_accueil,
                    'commentaire': request.user.profile.manager.profile.company.commentaire,
                },
                'hexagramme': request.user.profile.manager.profile.hexagramme,
                'trigramme': request.user.profile.manager.profile.trigramme,
                'groupes': get_groups(request.user.profile.manager),
                'permissions': get_permissions(request.user.profile.manager),
            },
            'suppleant': {
                'id': request.user.profile.suppleant.id,
                'pk': request.user.profile.suppleant.id,
                'username': request.user.profile.suppleant.username,
                'email': request.user.profile.suppleant.email,
                'first_name': request.user.profile.suppleant.first_name,
                'last_name': request.user.profile.suppleant.last_name,
                'company': {
                    'raison_sociale': request.user.profile.suppleant.profile.company.raison_sociale,
                    'adresse': request.user.profile.suppleant.profile.company.adresse,
                    'code_postal': request.user.profile.suppleant.profile.company.code_postal,
                    'ville': request.user.profile.suppleant.profile.company.ville,
                    'site_web': request.user.profile.suppleant.profile.company.site_web,
                    'tel_accueil': request.user.profile.suppleant.profile.company.tel_accueil,
                    'commentaire': request.user.profile.suppleant.profile.company.commentaire,
                },
                'hexagramme': request.user.profile.suppleant.profile.hexagramme,
                'trigramme': request.user.profile.suppleant.profile.trigramme,
                'groupes': get_groups(request.user.profile.suppleant),
                'permissions': get_permissions(request.user.profile.suppleant),
            },
            'company': {
                'raison_sociale': request.user.profile.company.raison_sociale,
                'adresse': request.user.profile.company.adresse,
                'code_postal': request.user.profile.company.code_postal,
                'ville': request.user.profile.company.ville,
                'site_web': request.user.profile.company.site_web,
                'tel_accueil': request.user.profile.company.tel_accueil,
                'commentaire': request.user.profile.company.commentaire,
        },
            'hexagramme': request.user.profile.hexagramme,
            'trigramme': request.user.profile.trigramme,
            'groupes': get_groups(request.user),
            'permissions': get_permissions(request.user),
            'token': str(request.user.auth_token),
        }
        
    return JsonResponse(user, safe=False)
