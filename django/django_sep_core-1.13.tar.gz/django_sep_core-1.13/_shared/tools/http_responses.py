import os
from django.http import FileResponse


class SepFileResponse(FileResponse):
    def __init__(self,filepath, remove_after_transmission=True):
        self.filepath = filepath
        self.remove_after_transmission = remove_after_transmission
        # self['Access-Control-Allow-Headers'] = 'Content-Disposition'
        super().__init__(open(self.filepath.encode('utf-8'), 'rb'),
                         as_attachment=False,
                         filename=os.path.basename(self.filepath))

    def close(self):
        super().close()
        if self.remove_after_transmission:
            os.remove(self.filepath)
