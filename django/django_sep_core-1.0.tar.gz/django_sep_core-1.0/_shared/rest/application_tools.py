from django.http import JsonResponse, HttpRequest

from app_version import CURRENT_APP_VERSION


def get_current_app_version(request: HttpRequest):
    return JsonResponse(CURRENT_APP_VERSION, safe=False)
