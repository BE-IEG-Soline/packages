import django.contrib.auth.models
from rest_framework import serializers, viewsets
from rest_framework.response import Response

from _shared.serializers import UserSerializer


class GroupSerializer(serializers.ModelSerializer):
    manager = serializers.SerializerMethodField()
    adjoint = serializers.SerializerMethodField()
    sub_groups = serializers.SerializerMethodField()
    imputable = serializers.SerializerMethodField()
    top_group = serializers.SerializerMethodField()

    def get_imputable(self, group: django.contrib.auth.models.Group):
        if hasattr(group, 'extended_properties') == False or group.extended_properties.imputable is None:
            return False
        else:
            return group.extended_properties.imputable

    def get_top_group(self, group: django.contrib.auth.models.Group):
        if hasattr(group, 'extended_properties') == False or group.extended_properties.top_group is None:
            return False
        else:
            return group.extended_properties.top_group

    def get_sub_groups(self, group: django.contrib.auth.models.Group):
        groups = []
        if hasattr(group, 'groupes_enfants') == True:
            for sub_group in group.groupes_enfants.all().order_by('group__name'):
                groups.append(GroupSerializer(sub_group.group).data)
        return groups

    def get_manager(self, group: django.contrib.auth.models.Group):
        if hasattr(group, 'extended_properties') == False or group.extended_properties.manager is None:
            return None
        else:
            user = UserSerializer(group.extended_properties.manager).data
            user.pop('password')
            return user

    def get_adjoint(self, group: django.contrib.auth.models.Group):
        if hasattr(group, 'extended_properties') == False or group.extended_properties.adjoint is None:
            return None
        else:
            user = UserSerializer(group.extended_properties.adjoint).data
            user.pop('password')
            return user

    class Meta:
        model = django.contrib.auth.models.Group
        exclude = ['permissions']


class GroupViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = django.contrib.auth.models.Group.objects.distinct().all().order_by('name')
    serializer_class = GroupSerializer

    def list(self, request, *args, **kwargs):
        name = request.GET.get('name', None)
        top_group = request.GET.get('top_group', None)
        name_filter = request.GET.get('name_filter', None)

        if top_group is not None:
            self.queryset = self.queryset.get(extended_properties__top_group=True)
            serializer = GroupSerializer(self.queryset, many=False)
        else:
            if name is not None:
                self.queryset = self.queryset.filter(name__startswith=name)
            serializer = GroupSerializer(self.queryset, many=True)

        return Response(data=serializer.data)

