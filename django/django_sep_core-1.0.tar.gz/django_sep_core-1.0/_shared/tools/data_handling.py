def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]


def frange(start, stop, step):
    # fonction range avec des float
    i = start
    while i < stop:
        yield i
        i += step


def array_chunks_from_string(input: str, chunk_size: int) -> str:
    for i in range(0, len(input), chunk_size):
        yield input[i:i+chunk_size]
