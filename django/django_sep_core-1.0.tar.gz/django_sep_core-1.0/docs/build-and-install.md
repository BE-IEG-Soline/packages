# build the package
- *cd* in the package root directory. here => *D:\\_PROJECTS\\_new-arch\\_django-sep-core*
- **python setup.py sdist**

# install or update package
- *cd* in the python project root directory. here => *D:\\_PROJECTS\\_new-arch\\documents*
- **pip install --upgrade D:\\_PROJECTS\\_new-arch\\_django-sep-core\\dist\\django-sep-core-0.8.tar.gz**

