=====
_shared
=====

_shared is a Django app to handle common operations for all the microservices which will be developed in the SEP.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "_shared" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        '_shared',
    ]

2. Include the _shared URLconf in your project urls.py like this::

    path('_shared/', include('_shared.urls')),

3. Run ``python manage.py migrate`` to create the _shared models.

4. Start the development server and visit http://127.0.0.1:8000/admin/

5. Visit http://127.0.0.1:8000/_shared/ to view all the exposed services