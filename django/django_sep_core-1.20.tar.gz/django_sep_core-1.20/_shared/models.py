import re
import numpy
from django.contrib.auth.models import User, Group
from django.db import models
from _shared.tools.data_handling import array_chunks_from_string


class AbstractModel(models.Model):
    """
    Classe de base permettant de généraliser le stockage de dates et utilisateur de création et modification
    """
    user_cr = models.CharField(max_length=32)
    date_cr = models.DateField(auto_now_add=True)
    user_up = models.CharField(max_length=32)
    date_up = models.DateField(auto_now=True)

    class Meta:
        abstract = True

    def __str__(self):
        if hasattr(self, 'libelle'):
            return self.libelle
        elif hasattr(self, 'name'):
            return self.name
        elif hasattr(self, 'code'):
            return self.code
        else:
            return str(self)


class Societe(AbstractModel):
    raison_sociale = models.CharField(unique=True, max_length=128)
    adresse = models.CharField(max_length=128, blank=True, null=True)
    code_postal = models.CharField(max_length=16, blank=True, null=True)
    ville = models.CharField(max_length=64, blank=True, null=True)
    site_web = models.CharField(max_length=128, blank=True, null=True)
    tel_accueil = models.CharField(max_length=16, blank=True, null=True)
    commentaire = models.CharField(max_length=1024, blank=True, null=True)

    def __str__(self):
        return self.raison_sociale

    class Meta:
        managed = True
        db_table = 'shared_societe'


class History(models.Model):
    source_table = models.CharField(max_length=256)
    source_id = models.IntegerField(blank=True, null=True)
    source_column = models.CharField(max_length=256)
    operation = models.CharField(max_length=64)
    before_value = models.CharField(max_length=2048, blank=True, null=True)
    after_value = models.CharField(max_length=2048, blank=True, null=True)
    user = models.CharField(max_length=32, blank=True, null=True)
    upd_date = models.DateField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'shared_historique'


class GroupExtendedProperty(models.Model):
    group = models.OneToOneField(Group, on_delete=models.CASCADE, related_name='extended_properties')
    groupe_parent = models.ForeignKey(Group, null=True, blank=True, on_delete=models.RESTRICT, related_name='groupes_enfants')
    top_group = models.BooleanField(null=True, blank=True)
    imputable = models.BooleanField(null=True, blank=True, default=True)
    manager = models.ForeignKey(User, on_delete=models.RESTRICT, null=True, blank=True, related_name='group_manager')
    adjoint = models.ForeignKey(User, on_delete=models.RESTRICT, null=True, blank=True, related_name='group_adjoint')
    nom_commun = models.CharField(max_length=200, null=True)

    class Meta:
        managed = True
        db_table = 'shared_group_extended_property'


class StatutCollaborateur(models.Model):
    libelle = models.CharField(max_length=200)

    def __str__(self):
        return self.libelle

    class Meta:
        managed = True
        db_table = 'shared_statut_collaborateur'


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    manager = models.ForeignKey(User, on_delete=models.RESTRICT, null=True, related_name='manager_collaborateurs')
    suppleant = models.ForeignKey(User, on_delete=models.RESTRICT, null=True, related_name='suppleant_collaborateurs')
    company = models.ForeignKey(Societe, on_delete=models.RESTRICT, null=True, related_name='collaborateurs')
    prestation_company = models.ForeignKey(Societe, on_delete=models.RESTRICT, null=True, related_name='collaborateurs_prestataire')
    statut_collaborateur = models.ForeignKey(StatutCollaborateur, on_delete=models.RESTRICT, null=True, related_name='profils')
    hexagramme = models.CharField(max_length=6, null=True)
    trigramme = models.CharField(max_length=3, null=True)
    prestataire = models.BooleanField(null=True, default=False)

    class Meta:
        managed = True
        db_table = 'shared_user_profile'


class Palier(AbstractModel):
    code = models.CharField(max_length=10)
    libelle = models.CharField(max_length=256)

    def __str__(self):
        return self.libelle

    class Meta:
        managed = True
        db_table = 'shared_palier'


class Site(AbstractModel):
    palier = models.ForeignKey(Palier, on_delete=models.RESTRICT, related_name='sites')
    code = models.CharField(max_length=10)
    libelle = models.CharField(max_length=256)

    def __str__(self):
        return self.libelle

    class Meta:
        managed = True
        db_table = 'shared_site'


class Tranche(AbstractModel):
    libelle = models.CharField(max_length=256)
    sites = models.ManyToManyField(Site, related_name='tranches')
    lettre = models.CharField(max_length=256)
    affectation = models.CharField(max_length=256)

    def __str__(self):
        return self.libelle

    class Meta:
        managed = True
        db_table = 'shared_tranche'


class Validite(AbstractModel):
    code = models.CharField(max_length=128)
    libelle = models.CharField(max_length=128)

    def __str__(self):
        return self.libelle

    class Meta:
        managed = True
        db_table = 'shared_validite'

    def array_intersection(self, a, b):
        ret = []
        for pa in a:
            if pa in b:
                ret.append(pa)

        return ret

    def synchronize_validite_with_external_one(self, validite_indice: str):
        """
        Permet de synchroniser les validités de l'instance avec celles d'un document
        :param validite_indice: Les validités attendues sont une suite de sites/tranches => 'PA1PA2PA3PA4SA1SA2FA1FA2'
        :return: Les validités réduites, si nécessaire
        """
        # transformation de notre validité en tableau
        validite_courante = self.transform_validite_as_array(self.libelle)
        validite_indice = list(array_chunks_from_string(validite_indice, 3))
        kept_validites = []
        for val in validite_courante:
            if val in validite_indice:
                kept_validites.append(val)

        # on fait la transformation inverse (array => string) et on retourne ça à l'appelant
        return self.transform_array_as_validite(kept_validites)

    def is_in_regroupement(self, regroupement):
        val = set(self.transform_validite_as_array(self.libelle))
        reg = set(regroupement)

        return len(reg & val) > 0

    def transform_array_as_validite(self, validite_array):
        vals = {}
        for val in validite_array:
            if val[:2] not in vals.keys():
                vals[val[:2]] = val[2:]
            else:
                vals[val[:2]] += val[2:]
        r = ''
        for k in vals.keys():
            r += '{}({}) '.format(k, vals[k])

        return r.rstrip()

    def get_libelle_as_array(self):
        return self.transform_validite_as_array(self.libelle)

    def transform_validite_as_array(self, validite):
        vals = validite.split()
        ret_val = []
        for val in vals:
            tab = re.match("(\w+)\((\d+)\)", val)
            site = tab.groups()[0]
            for tranche in tab.groups()[1]:
                ret_val.append('{}{}'.format(site, tranche))
        return ret_val

    def transform_validites_as_array(self, validites):
        ret_vals = []
        for row in validites:
            ret_vals.append(self.transform_validite_as_array(row))
        return ret_vals

    def generateIndividualValidites(self, details):
        details = self.transform_validites_as_array(details)
        validites = numpy.array(details, dtype=object)
        validites = numpy.concatenate(validites, axis=None)
        validites = numpy.unique(validites)

        validites = validites.tolist()
        validites = [[val] for val in validites]

        return validites

    def generatePpcmValArray(self, details):
        details = self.transform_validites_as_array(details)

        identical_vals = True
        c = details[0]
        for d in details:
            if c != d:
                identical_vals = False

        if identical_vals:
            return [details[0]]

        i = 500  # <<<<<< WOOOOTTT MAGIC NUMBER FOR ITERATIONS
        intersections = True
        while i and intersections:
            i -= 1

            # suppression des doublons dans le tableau des validités.
            tmp_vals = [details[0]]
            for pval in details:
                if pval not in tmp_vals:
                    tmp_vals.append(pval)

            details = sorted(tmp_vals)

            tmp_arr = []
            try:
                c = details.pop(0)
            except:
                c = None
            while c:
                found_intersections = False
                for x in range(len(details)):
                    detail = details[x]
                    intersection = self.array_intersection(c, detail)
                    if len(intersection):
                        dif_a = detail
                        for inter in intersection:
                            dif_a.remove(inter)
                        dif_b = c
                        for inter in intersection:
                            dif_b.remove(inter)

                        # suppressions
                        if details in tmp_arr:
                            tmp_arr.remove(details)

                        if c in tmp_arr:
                            tmp_arr.remove(c)

                        # ajouts...
                        if intersection not in tmp_arr:
                            tmp_arr.append(intersection)
                        if dif_a not in tmp_arr and len(dif_a):
                            tmp_arr.append(dif_a)
                        if dif_b not in tmp_arr and len(dif_b):
                            tmp_arr.append(dif_b)

                        found_intersections = True
                    else:
                        if c not in tmp_arr:
                            tmp_arr.append(c)
                        if detail not in tmp_arr:
                            tmp_arr.append(detail)

                    if found_intersections:
                        x += 1
                        for x in range(len(details)):
                            if details[x] not in tmp_arr:
                                tmp_arr.append(details[x])
                        break

                if found_intersections:
                    details = tmp_arr
                    intersections = True
                    break
                else:
                    intersections = False

                try:
                    c = details.pop(0)
                except:
                    c = None

        return tmp_arr

    def compare_function(self, x, y):
        # recherche de plusieurs sites
        msx = re.findall(r'(\w*\(\d*\))+', x)
        msy = re.findall(r'(\w*\(\d*\))+', y)

        if len(msx) > 1 or len(msy) > 1:
            if len(msx) != len(msy):
                return len(msx) - len(msy)
            else:
                for i in range(len(msx)):
                    r = self.compare_function(msx[i], msy[i])
                    if r != 0:
                        return r
                return 0
        else:
            if x[:2] < y[:2]:
                return -1
            elif x[:2] > y[:2]:
                return 1
            else:
                mx = re.search('\w*\((\d*)\)', x)
                my = re.search('\w*\((\d*)\)', y)
                ix = int(mx.group(1))
                iy = int(my.group(1))
                return ix - iy


class Contrat(AbstractModel):
    C90000 = 1
    C96100 = 11
    C1046850_ETUDES = 12
    C1046850_PROJET = 13
    MARCHE_CXXXX = 15

    code = models.CharField(max_length=32, default='CODE_TEMP')
    libelle = models.CharField(max_length=128)

    class Meta:
        managed = True
        db_table = 'shared_contrat'

    def __str__(self):
        return self.libelle


class Uce(AbstractModel):
    code = models.CharField(max_length=32)
    lettre = models.CharField(max_length=10)
    libelle = models.CharField(max_length=512)
    adresse = models.CharField(max_length=512)
    ville = models.CharField(max_length=256)
    tel_accueil = models.CharField(max_length=20)

    class Meta:
        managed = True
        db_table = 'shared_uce'

    def __str__(self):
        return self.libelle


class Service(AbstractModel):
    # CSM, ACI, AFI, ARC...
    uce = models.ForeignKey(Uce, models.RESTRICT, related_name='services')
    code = models.CharField(max_length=10)
    libelle = models.CharField(max_length=64)

    class Meta:
        managed = True
        db_table = 'shared_service'

    def __str__(self):
        return '{} - {}'.format(self.uce.libelle, self.libelle)


class Qualification(AbstractModel):
    QUALIFICATION_NQ = 0
    QUALIFICATION_K3 = 1
    QUALIFICATION_K3ad = 2
    QUALIFICATION_K2 = 3
    QUALIFICATION_K1 = 4
    QUALIFICATION_AG = 5

    libelle = models.CharField(max_length=64)

    def __str__(self):
        return self.libelle

    class Meta:
        managed = True
        db_table = 'shared_qualification'


class CahierDesChargesExterne(models.Model):
    id = models.IntegerField(primary_key=True)
    paliers = models.CharField(max_length=100)
    reference = models.CharField(max_length=12)
    tome = models.CharField(max_length=4)
    indice_tome = models.CharField(max_length=4)
    indice_externe = models.CharField(max_length=4)
    lot = models.CharField(max_length=20)
    uce = models.CharField(max_length=32)
    service = models.CharField(max_length=64)
    prescripteur = models.CharField(max_length=128)
    prescripteur_mail = models.CharField(max_length=128)
    pilote_id = models.IntegerField()
    pilote = models.CharField(max_length=128)
    pilote_mail = models.CharField(max_length=128)
    type = models.CharField(max_length=64)

    chrono_sep = models.CharField(max_length=6)

    libelle = models.CharField(max_length=2000)
    observations_externe = models.CharField(max_length=2000)
    date_reception = models.DateField()
    date_fin_etudes_edf = models.DateField(null=True)
    accelere = models.BooleanField(null=True)
    eips = models.BooleanField(null=True)
    aip = models.BooleanField(null=True)
    enjeu_edf = models.CharField(max_length=20)
    date_tts = models.DateField(null=True)
    diffusion_docs_tts = models.DateField(null=True)
    element_otp = models.CharField(max_length=200, null=True)

    validite_etudes_id = models.IntegerField()
    validite_etudes = models.CharField(max_length=512)
    validite_travaux_tes_id = models.IntegerField()
    validite_travaux_tes = models.CharField(max_length=512)
    validite_travaux_te_id = models.IntegerField()
    validite_travaux_te = models.CharField(max_length=512)
    validite_tts_id = models.IntegerField()
    validite_tts = models.CharField(max_length=512)

    dosimetrie_edf = models.IntegerField(null=True)
    dosimetrie_tes = models.IntegerField(null=True)
    dosimetrie_te = models.IntegerField(null=True)

    date_previsionnelle_travaux = models.DateField(null=True)

    date_annulation = models.DateField(null=True)
    date_cloture = models.DateField(null=True)

    class Meta:
        managed = False
        db_table = 'shared_cahier_des_charges_externe_view'

    def __str__(self):
        return f'{self.reference}{self.tome}{self.indice_tome}{self.indice_externe}'


# spécifique cahiers des charges.
class CahierDesChargesInterne(models.Model):
    id = models.IntegerField(primary_key=True)
    paliers = models.CharField(max_length=100)
    reference = models.CharField(max_length=12)
    tome = models.CharField(max_length=4)
    indice_tome = models.CharField(max_length=4)
    indice_externe = models.CharField(max_length=4)
    lot = models.CharField(max_length=20)
    uce = models.CharField(max_length=32)
    service = models.CharField(max_length=64)
    prescripteur = models.CharField(max_length=128)
    prescripteur_mail = models.CharField(max_length=128)
    pilote_id = models.IntegerField()
    pilote = models.CharField(max_length=128)
    pilote_mail = models.CharField(max_length=128)
    type = models.CharField(max_length=64)

    chrono_sep = models.CharField(max_length=6)

    libelle = models.CharField(max_length=2000)
    observations_externe = models.CharField(max_length=2000)
    date_reception = models.DateField()
    date_fin_etudes_edf = models.DateField(null=True)
    accelere = models.BooleanField(null=True)
    eips = models.BooleanField(null=True)
    aip = models.BooleanField(null=True)
    enjeu_edf = models.CharField(max_length=20)
    date_tts = models.DateField(null=True)
    diffusion_docs_tts = models.DateField(null=True)
    element_otp = models.CharField(max_length=200, null=True)

    validite_etudes_id = models.IntegerField()
    validite_etudes = models.CharField(max_length=512)
    validite_travaux_tes_id = models.IntegerField()
    validite_travaux_tes = models.CharField(max_length=512)
    validite_travaux_te_id = models.IntegerField()
    validite_travaux_te = models.CharField(max_length=512)
    validite_tts_id = models.IntegerField()
    validite_tts = models.CharField(max_length=512)

    dosimetrie_edf = models.IntegerField(null=True)
    dosimetrie_tes = models.IntegerField(null=True)
    dosimetrie_te = models.IntegerField(null=True)

    date_previsionnelle_travaux = models.DateField(null=True)

    date_annulation = models.DateField(null=True)
    date_cloture = models.DateField(null=True)

    indice_interne = models.CharField(max_length=4)
    contrat = models.CharField(max_length=10)

    visible_edf = models.BooleanField(null=True)
    etat = models.CharField(max_length=64)

    charge_etude_id = models.IntegerField()
    charge_etude = models.CharField(max_length=128)
    charge_etude_mail = models.CharField(max_length=128)
    origine_montee_edf = models.BooleanField(null=True)
    impact_offre_etude = models.BooleanField(null=True)
    observations_interne = models.CharField(max_length=2000)

    class Meta:
        managed = False
        db_table = 'shared_cahier_des_charges_interne_view'

    def __str__(self):
        return f'{self.reference}{self.tome}{self.indice_tome}{self.indice_externe}-{self.chrono_sep}{self.indice_interne}'


class Batiment(AbstractModel):
    tranches = models.ManyToManyField(Tranche, related_name='batiments', db_table='shared_batiment_tranche')
    trigramme = models.CharField(max_length=3)
    repere = models.CharField(max_length=1)
    libelle = models.CharField(max_length=32)
    num_bat_cdc_il = models.CharField(max_length=10)
    num_bat_malt_inst = models.CharField(max_length=10)
    num_chro_cdc_malt = models.CharField(max_length=10)
    num_chro_il = models.CharField(max_length=10)
    num_chro_inst = models.CharField(max_length=10)

    class Meta:
        db_table = 'shared_batiment'
        managed = True


class Local(AbstractModel):
    batiments = models.ManyToManyField(Batiment, related_name='locaux', db_table='shared_local_batiment')
    code = models.CharField(max_length=64)
    libelle = models.CharField(max_length=128)

    class Meta:
        db_table = 'shared_local'
        managed = True


class Voile(AbstractModel):
    batiments = models.ManyToManyField(Batiment, related_name='voiles', db_table='shared_voile_batiment')
    code = models.CharField(max_length=64)
    libelle = models.CharField(max_length=128)

    class Meta:
        db_table = 'shared_voile'
        managed = True

