import json

from django.contrib.auth import get_user_model
from django.http import HttpResponse

from _shared.models import Validite
from _shared.serializers import ValiditeSerializer

UserClass = get_user_model()

def load_validite(request, id):
    data_tab = []

    for element in Validite.objects.filter(id=id):
        serial = ValiditeSerializer(element)
        data_tab = serial.data

    return HttpResponse(json.dumps(data_tab), content_type='application/json')

def search_validite(request, libelle: str):
    data_tab = []

    for element in Validite.objects.filter(libelle=libelle):
        serial = ValiditeSerializer(element)
        data_tab.append(serial.data)

    return HttpResponse(json.dumps(data_tab), content_type='application/json')


def add_validite(request):
    body_decode = request.body.decode('utf-8')
    body = json.loads(body_decode)

    try:
        existent_validite = Validite.objects.get(code=body['code'])
        print(f'Validité existante => {existent_validite.id}')
    except Exception as exc:
        existent_validite = None
        print(f'Exception happened => {exc}')

    if existent_validite is None:
        print(f"Création d'une nouvelle validité")
        validite = Validite()
        validite.code = body['code']
        validite.libelle = body['libelle']
        validite.save()
    else:
        validite = existent_validite

    return HttpResponse(json.dumps(validite.id), content_type='application/json')


def update_validite(request, id: int):
    body_decode = request.body.decode('utf-8')
    body = json.loads(body_decode)

    try:
        existent_validite = Validite.objects.get(code=body['code'])
    except:
        existent_validite = None

    if existent_validite is None:
        if id is not None:
            validite = Validite.objects.get(id=body['id'])
            validite.code = body['code']
            validite.libelle = body['libelle']
            validite.save()
        else:
            validite = Validite()
            validite.code = body['code']
            validite.libelle = body['libelle']
            validite.save()
    else:
        validite = existent_validite

    return HttpResponse(json.dumps(validite.id), content_type='application/json')
