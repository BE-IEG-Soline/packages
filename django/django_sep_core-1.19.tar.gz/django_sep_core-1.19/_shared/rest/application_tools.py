from django.http import JsonResponse, HttpRequest

from environment import EXECUTION_MODE, VERSION


def get_current_app_version(request: HttpRequest):
    return JsonResponse(VERSION, safe=False)
