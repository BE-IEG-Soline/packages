from django.contrib.auth.models import User, Group

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin, GroupAdmin
from django.contrib.contenttypes.models import ContentType

from django.contrib.auth.models import Permission

from _shared.models import GroupExtendedProperty, Societe, Palier, Site, Tranche, Batiment, Local, Voile
from _shared.models import Profile, Validite, Contrat, Uce, Service, Qualification, StatutCollaborateur

@admin.register(Permission)
class PermissionAdmin(admin.ModelAdmin):
    DJANGO_CONTENT_TYPE_FRONTEND_DEFAULT = 0
    list_display = ('id', 'name', 'content_type', 'codename')
    exclude = ('content_type',)

    def get_exclude(self, request, obj=None):
        return ("content_type",)

    def save_model(self, request, obj, form, change):
        content_type = ContentType.objects.get(pk=self.DJANGO_CONTENT_TYPE_FRONTEND_DEFAULT)
        obj.content_type = content_type
        obj.content_type_id = self.DJANGO_CONTENT_TYPE_FRONTEND_DEFAULT
        print(request)
        print(type(obj))
        print(form)
        print(change)
        obj.save()
        super(PermissionAdmin, self).save_model(request, obj, form, change)


class GroupExtendedPropertyInline(admin.StackedInline):
    model = GroupExtendedProperty
    can_delete = False
    fk_name = 'group'


class UserProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    fk_name = 'user'


class ManagerProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    fk_name = 'manager'


class SepUserAdmin(UserAdmin):
    inlines = [UserProfileInline]

    def get_form(self, request, obj=None, **kwargs):
        form = super(SepUserAdmin, self).get_form(request, obj, **kwargs)
        # adding a User via the Admin doesn't include the permissions at first
        if 'user_permissions' in form.base_fields:
            permissions = form.base_fields['user_permissions']
            permissions.queryset = permissions.queryset.filter(content_type__app_label='frontend').order_by('name')
        return form


class SepGroupAdmin(GroupAdmin):
    inlines = [GroupExtendedPropertyInline]

    def get_form(self, request, obj=None, **kwargs):
        form = super(SepGroupAdmin, self).get_form(request, obj, **kwargs)
        # adding a User via the Admin doesn't include the permissions at first
        if 'permissions' in form.base_fields:
            permissions = form.base_fields['permissions']
            permissions.queryset = permissions.queryset.filter(content_type__app_label='frontend').order_by('name')
        return form


class SocieteAdmin(admin.ModelAdmin):
    list_display = ('id', 'raison_sociale', 'adresse', 'code_postal', 'ville', 'site_web', 'tel_accueil')


class PalierAdmin(admin.ModelAdmin):
    pass


class SiteAdmin(admin.ModelAdmin):
    pass


class TrancheAdmin(admin.ModelAdmin):
    pass


class ValiditeAdmin(admin.ModelAdmin):
    pass


class ContratAdmin(admin.ModelAdmin):
    pass


class UceAdmin(admin.ModelAdmin):
    pass


class ServiceAdmin(admin.ModelAdmin):
    pass


class QualificationAdmin(admin.ModelAdmin):
    pass


class BatimentAdmin(admin.ModelAdmin):
    pass


class LocalAdmin(admin.ModelAdmin):
    pass


class VoileAdmin(admin.ModelAdmin):
    pass


class StatutCollaborateurAdmin(admin.ModelAdmin):
    pass

admin.site.unregister(User)
admin.site.register(User, SepUserAdmin)
admin.site.unregister(Group)
admin.site.register(Group, SepGroupAdmin)
admin.site.register(Societe, SocieteAdmin)
admin.site.register(Palier, PalierAdmin)
admin.site.register(Site, SiteAdmin)
admin.site.register(Tranche, TrancheAdmin)
admin.site.register(Validite, ValiditeAdmin)
admin.site.register(Contrat, ContratAdmin)
admin.site.register(Uce, UceAdmin)
admin.site.register(Service, ServiceAdmin)
admin.site.register(Qualification, QualificationAdmin)
admin.site.register(Batiment, BatimentAdmin)
admin.site.register(Local, LocalAdmin)
admin.site.register(Voile, VoileAdmin)
admin.site.register(StatutCollaborateur, StatutCollaborateurAdmin)
