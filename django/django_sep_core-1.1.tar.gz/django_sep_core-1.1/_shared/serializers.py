from django.conf.global_settings import AUTH_USER_MODEL
from django.contrib.auth import get_user_model
from rest_framework import serializers

from _shared.models import Societe, Profile, Validite, Palier, Site, Tranche, Contrat, Service, Uce, \
    CahierDesChargesInterne, \
    Qualification, Batiment, Local, Voile

UserClass = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    groups = serializers.SerializerMethodField()
    permissions = serializers.SerializerMethodField()

    class Meta:
        model = UserClass
        # fields = '__all__'
        fields = ('id', 'username', 'first_name', 'last_name', 'email', 'is_superuser', 'is_staff', 'is_active', 'date_joined', 'last_login', 'groups', 'permissions')

    def get_groups(self, obj: AUTH_USER_MODEL):
        groups_list = []
        for groupe in obj.groups.all():
            groups_list.append(groupe.name)

        return groups_list

    def get_permissions(self, obj):
        permission_list = []
        for groupe in obj.groups.all():
            # permissions des groupes auxquels l'utilisateur appartient
            for permission in groupe.permissions.all():
                if permission.codename not in permission_list:
                    permission_list.append(permission.codename)

        # permissions de l'utilisateur
        for permission in obj.get_user_permissions():
            if permission not in permission_list:
                permission_list.append(permission)

        return permission_list


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = '__all__'


class SocieteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Societe
        fields = '__all__'


class ValiditeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Validite
        fields = '__all__'


class PalierSerializer(serializers.ModelSerializer):
    class Meta:
        model = Palier
        fields = '__all__'


class SiteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Site
        fields = '__all__'


class TrancheSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tranche
        fields = '__all__'


class ContratSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contrat
        fields = '__all__'


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = '__all__'


class UceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Uce
        fields = '__all__'


class CahierDesChargesSerializer(serializers.ModelSerializer):
    class Meta:
        model = CahierDesChargesInterne
        fields = '__all__'


class QualificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Qualification
        fields = '__all__'


class BatimentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Batiment
        fields = '__all__'


class LocalSerializer(serializers.ModelSerializer):
    class Meta:
        model = Local
        fields = '__all__'


class VoileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Voile
        fields = '__all__'

