# build the package
- *cd* in the package root directory. here => *D:\\_PROJECTS\\_django-sep-core*
- **python setup.py sdist**

# install or update package
- *cd* in the python project root directory. here => *D:\\_PROJECTS\\documents*
- **pip install --upgrade D:\\_PROJECTS\\_django-sep-core\\dist\\django-sep-core-0.8.tar.gz**
OR
- **pip install --upgrade https://github.com/BE-IEG-Soline/packages/raw/main/django/django_sep_core-1.0.tar.gz**
