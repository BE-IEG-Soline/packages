from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('_shared', '0006_contrat_code'),
    ]

    operations = [
        migrations.CreateModel(
            name='Batiment',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('user_cr', models.CharField(max_length=32)),
                ('date_cr', models.DateField(auto_now_add=True)),
                ('user_up', models.CharField(max_length=32)),
                ('date_up', models.DateField(auto_now=True)),
                ('tranches', models.ManyToManyField(blank=True, db_table='shared_batiment_tranche', related_name='batiments', to='_shared.tranche')),
                ('trigramme', models.CharField(max_length=3)),
                ('repere', models.CharField(max_length=1)),
                ('libelle', models.CharField(max_length=32)),
                ('num_bat_cdc_il', models.CharField(max_length=10)),
                ('num_bat_malt_inst', models.CharField(max_length=10)),
                ('num_chro_cdc_malt', models.CharField(max_length=10)),
                ('num_chro_il', models.CharField(max_length=10)),
                ('num_chro_inst', models.CharField(max_length=10)),
            ],
            options={
                'db_table': 'shared_batiment',
                'managed': True,
            },
        ),
        migrations.CreateModel(
            name='Local',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('user_cr', models.CharField(max_length=32)),
                ('date_cr', models.DateField(auto_now_add=True)),
                ('user_up', models.CharField(max_length=32)),
                ('date_up', models.DateField(auto_now=True)),
                ('batiments', models.ManyToManyField(blank=True, db_table='shared_local_batiment', related_name='locaux', to='_shared.batiment')),
                ('code', models.CharField(max_length=64)),
                ('libelle', models.CharField(max_length=128)),
            ],
            options={
                'db_table': 'shared_local',
                'managed': True,
            },
        ),
        migrations.CreateModel(
            name='Voile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('user_cr', models.CharField(max_length=32)),
                ('date_cr', models.DateField(auto_now_add=True)),
                ('user_up', models.CharField(max_length=32)),
                ('date_up', models.DateField(auto_now=True)),
                ('batiments', models.ManyToManyField(blank=True, db_table='shared_voile_batiment', related_name='voiles', to='_shared.batiment')),
                ('code', models.CharField(max_length=64)),
                ('libelle', models.CharField(max_length=128)),
            ],
            options={
                'db_table': 'shared_voile',
                'managed': True,
            },
        ),
    ]
