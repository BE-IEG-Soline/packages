from django.urls import path, re_path
from rest_framework.routers import DefaultRouter

from _shared.rest.application_tools import get_current_app_version
from _shared.rest.form_token import FormToken
from _shared.rest.group_api import GroupViewSet
from _shared.rest.user_api import UserList, change_user_password, is_already_logged_in
from _shared.rest.user_api import get_user_informations
from _shared.rest.user_api import get_perms
from _shared.rest.user_api import get_user_profile
from _shared.rest.user_api import get_upper_user_hierarchy
from _shared.rest.user_api import get_lower_user_hierarchy
from _shared.rest.user_api import get_simple_user_list
from _shared.rest.user_api import refresh_connected_user_data
from _shared.validite_views import load_validite, search_validite, add_validite, update_validite

from _shared.viewsets import HistoryViewSet, SocieteViewSet, ValiditeViewSet, PalierViewSet, SiteViewSet, \
    TrancheViewSet, VoileViewSet, LocalViewSet, BatimentViewSet
from _shared.viewsets import ContratViewSet, UceViewSet, ServiceViewSet, CahierDesChargesViewSet, QualificationViewSet

router = DefaultRouter()
router.register(r'group', GroupViewSet, basename='group')

router.register(r'historique', HistoryViewSet, basename='historique')
router.register(r'societe', SocieteViewSet, basename='societe')
router.register(r'palier', PalierViewSet, basename='palier')
router.register(r'site', SiteViewSet, basename='site')
router.register(r'tranche', TrancheViewSet, basename='tranche')
router.register(r'batiment', BatimentViewSet, basename='batiment')
router.register(r'local', LocalViewSet, basename='local')
router.register(r'voile', VoileViewSet, basename='voile')
router.register(r'contrat', ContratViewSet, basename='contrat')
router.register(r'uce', UceViewSet, basename='uce')
router.register(r'service', ServiceViewSet, basename='service')
router.register(r'cahier-des-charges', CahierDesChargesViewSet, basename='cahier-des-charges')
router.register(r'qualification', QualificationViewSet, basename='qualification')


urlpatterns = [
    path('get-form-token/', FormToken.as_view()),
    path('user-list/', UserList.as_view()),
    path('simple-user-list/', get_simple_user_list, name='simple-user-list'),
    path('get-user-informations/', get_user_informations, name='get-user-informations'),
    path('refresh-connected-user-data/', refresh_connected_user_data, name='refresh-connected-user-data'),
    path('get-perms/', get_perms, name='get-perms'),
    path('get-user-profile/', get_user_profile, name='get-user-profile'),
    path('get-upper-user-hierarchy/', get_upper_user_hierarchy, name='get-upper-user-hierarchy'),
    path('get-lower-user-hierarchy/', get_lower_user_hierarchy, name='get-lower-user-hierarchy'),
    path('get-current-app-version/', get_current_app_version, name='get-current-app-version'),
    path('change-password/', change_user_password, name='change-password'),
    path('is-already-logged-in/',is_already_logged_in, name='is-already-logged-in'),
    re_path(r'validite/(?P<id>[0-9]{1,8})', load_validite, name='load-validite'),
    re_path(r'validite/search/(?P<libelle>[\w\s])', search_validite, name='search-validite'),
    re_path(r'validite/save/', add_validite, name='save-validite'),
    re_path(r'validite/save/(?P<id>[0-9]{1,8})/', update_validite, name='save-validite'),

]

urlpatterns += router.urls

